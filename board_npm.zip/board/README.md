
  # Optometrist Dashboard

  This is a code bundle for Optometrist Dashboard. The original project is available at https://www.figma.com/design/xZPyGjMse7dn0poy4FQmDz/Optometrist-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  